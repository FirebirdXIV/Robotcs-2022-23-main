package org.firstinspires.ftc.teamcode.subsystems.LiftArm;

public enum LiftHeight
{
    TOP,
    MIDDLE,
    BOTTOM,
    DRIVE,
    PICKUP,
    ZERO,
    CAP

}
