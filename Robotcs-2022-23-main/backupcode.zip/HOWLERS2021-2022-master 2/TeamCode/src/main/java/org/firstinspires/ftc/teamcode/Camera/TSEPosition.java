package org.firstinspires.ftc.teamcode.Camera;



public enum TSEPosition {
    LEFT,
    CENTER,
    RIGHT,
}
